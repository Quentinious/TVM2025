import { AnnotatedModule, Formula } from "./funnier";

export function resolveModule(m: AnnotatedModule): AnnotatedModule 
{

  const formulaTable = new Map<string, Formula>();
  for (const f of m.formulas) 
    {
        if (formulaTable.has(f.name)) 
        {
            throw new Error(`Duplicate formula: ${f.name}`);
        }
        formulaTable.set(f.name, f);
  }

  // Функция проверки предиката
  function checkPredicate(pred: any, allowedVars: Set<string>, context: string)
    {
    if (!pred) 
        return;
    
    // Для узлов с kind
    if (pred.kind)
    {
      switch (pred.kind)
        {
            case "true": case "false": break;
            case "comparison": break; // Проверка Expr — в lab08
            case "and": case "or":
            checkPredicate(pred.left, allowedVars, context);
            checkPredicate(pred.right, allowedVars, context);
            break;
                case "not":
                checkPredicate(pred.predicate, allowedVars, context);
                break;
            case "paren":
                checkPredicate(pred.inner, allowedVars, context);
                break;
            case "quantifier": 
            {
                const extended = new Set(allowedVars);
                extended.add(pred.param.name);
                checkPredicate(pred.body, extended, context);
                break;
            }
            case "formula": 
            {
                const formula = formulaTable.get(pred.name);
                if (!formula) 
                {
                    throw new Error(`Undefined formula ${pred.name} in ${context}`);
                }
                if (formula.parameters.length !== pred.parameters.length) 
                {
                    throw new Error(`Formula ${pred.name} expects ${formula.parameters.length} args, got ${pred.parameters.length} in ${context}`);
                }
                break;
            }
        }
    }
    // Для массивов (например, precondition/postcondition)
    else if (Array.isArray(pred)) 
    {
      pred.forEach(p => checkPredicate(p, allowedVars, context));
    }
  }

  // Проверка формул
  for (const f of m.formulas)
    {
        const allowed = new Set(f.parameters.map(p => p.name));
        checkPredicate(f.body, allowed, `formula ${f.name}`);
    }

  // Проверка функций
  for (const fn of m.functions) 
    {
        const allowed = new Set(
        [...fn.parameters, ...fn.returns, ...fn.locals].map(p => p.name)
        );
        if (fn.precondition) checkPredicate(fn.precondition, allowed, `precondition of ${fn.name}`);
        if (fn.postcondition) checkPredicate(fn.postcondition, allowed, `postcondition of ${fn.name}`);
    }

  return m;
}
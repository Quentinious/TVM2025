import { parseFunnier } from '../src';
import { testFilesInFolder } from '../../lab08/tests/testFilesInFolder';


describe('10. Testing the sample files', () => {
    testFilesInFolder("./samples", parseFunnier);
});
// import { parseAndResolve } from '../src';
// import { testFilesInFolder } from '../../lab08/tests/testFilesInFolder';


// describe('10. Testing the sample files', () => {
//     testFilesInFolder("./lab10/samples", parseAndResolve);
// });

// D:\HelloWorld\TVM2025-public\lab08\tests\testFilesInFolder.ts
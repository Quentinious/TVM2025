//pnpm ts-node src/main.ts из src

// import { parseAndCompile } from "./index";

// async function main() 
// {
//     const source = `
//         test(x: int, y: int) 
//         returns a: int, b: int
//         {
//             a, b = y, x; 
//         }
//     `;

   
//     const mod = await parseAndCompile("test", source);

//     console.log("Compiled module exports:", mod); 

//     const result = mod.test(10, 20);
//     console.log(`Result of test(10, 20) (might be last return val): ${result}`);
// }

// main().catch(console.error);


//=========================2==============================//

// import { parseAndCompile } from "./index";

// async function main() 
// {
//     const source = `
//         test(val: int, arr: int[])
//         returns dummy: int[] 
//         {
//             arr[0] = val;
//             arr[1] = val * 2;
//             arr[2] = val * 3;
//             dummy = arr[2]; 
//         }
//     `;

//     const mod = await parseAndCompile("test", source);

//     const memory = mod.memory as WebAssembly.Memory;
//     const memBuffer = new Int32Array(memory.buffer);

//     // Подготовим место для выходного массива
//     const outputArrayStartIndex = 0;
//     const outputArrayLength = 3;
//     const pointerToOutArr = outputArrayStartIndex * 4; // 0

//     // Инициализируем, чтобы убедиться, что значения меняются
//     for (let i = outputArrayStartIndex; i < outputArrayStartIndex + outputArrayLength; i++) 
//     {
//         memBuffer[i] = 0;
//     }

//     console.log("Output array before function call:", Array.from(memBuffer.slice(outputArrayStartIndex, outputArrayStartIndex + outputArrayLength)));

//     // Вызов функции с двумя аргументами: val и указатель на массив
//     // Функция test теперь возвращает 0 (значение dummy)
//     const result = mod.test(5, pointerToOutArr);
//     console.log(`Function executed, returned (dummy): ${result}`);

//     console.log("Output array after function call:", Array.from(memBuffer.slice(outputArrayStartIndex, outputArrayStartIndex + outputArrayLength))); 
// }

// main().catch(console.error);

//========================3===========================//

import { parseAndCompile } from "./index";

async function main()
{
    const source = `
              test(arr:int[])
                returns res:int
                {
                arr[0] = 10;
                arr[1] = 20;
                res = arr[1] - arr[0];
                }
    `;

    const mod = await parseAndCompile("test", source);
    console.log("WASM exports:", Object.keys(mod)); // <-- Должно показать 'test' и 'memory'

    // --- ТЕПЕРЬ ПАМЯТЬ ДОСТУПНА КАК mod.memory ---
    const memory = mod.memory; // <-- Прямой доступ к WebAssembly.Memory
    if (!memory) {
        throw new Error("Compiled module does not export memory");
    }

    const memBuffer = new Int32Array(memory.buffer); // Представляем память как Int32Array

    // Выделяем место для массива arr (например, 10 элементов, начиная с индекса 0 в Int32Array)
    const arrayStartIndex = 0; // индекс в Int32Array
    const arrayLength = 3; // длина массива

    // Инициализируем массив (необязательно, но для ясности)
    for (let i = arrayStartIndex; i < arrayStartIndex + arrayLength; i++) {
        memBuffer[i] = 0;
    }

    // Указатель в байтах для WASM (каждый i32 = 4 байта)
    const pointerToArr = arrayStartIndex * 4; // индекс * размер i32

    console.log(`Calling test with pointerToArr (byte offset): ${pointerToArr}`);
    // --- ТЕПЕРЬ МОЖНО ВЫЗВАТЬ ФУНКЦИЮ С АРГУМЕНТОМ ---
    const result = mod.test(pointerToArr); // <-- Передаём указатель
    console.log(`Result: ${result}`); // Ожидаем 20 - 10 = 10

    // Проверим, изменились ли значения в массиве
    console.log("Array after function call (first 5 elements):", Array.from(memBuffer.slice(arrayStartIndex, arrayStartIndex + 5)));
}

main().catch(console.error);
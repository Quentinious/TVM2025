import { parseFunny} from "../../lab08";
import { compileModule as compileModuleFn } from "./compiler"; 

export class ExportWrapper implements Record<string, Function> 
{
  constructor(private exports: WebAssembly.Exports) {}
 
  get memory(): WebAssembly.Memory | undefined 
  {
    return (this.exports as any).memory as WebAssembly.Memory | undefined;
  }


  [key: string]: any; 

  static create(exports: WebAssembly.Exports): ExportWrapper
  {
    const wrapper = new ExportWrapper(exports);
    return new Proxy(wrapper, 
    {
      get: (target: ExportWrapper, prop: string) => 
        {
        if (prop === 'memory') 
        {
          return (target.exports as any).memory as WebAssembly.Memory | undefined;
        }
    
        const originalFunc = target.exports[prop];
        if (typeof originalFunc === 'function')
        {
          return (...args: any[]) => 
          {
         
            const f = originalFunc as Function; 
            const a = args;
            return f.apply(target.exports, args);
          };
        }
        return originalFunc;
      },
    });
  }
}

export async function parseAndCompile(name: string, source: string) 
{
  const ast = parseFunny(source); 
  const wasmExports = await compileModuleFn(ast);
  return ExportWrapper.create(wasmExports);
}
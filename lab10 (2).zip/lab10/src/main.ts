import { parseAndResolve } from "./index";

function run(source: string, name: string) {
  console.log(name);
  try {
    const ast = parseAndResolve(source);
    console.log(JSON.stringify(ast, null, 2));
  } catch (e) {
    console.error("Error:", e);
  }
}


const source1 = `
factorial(n: int) 
requires n >= 0
returns f: int
ensures (n == 0 and f == 1) or (f == n * factorial(n-1))
{
    if (n == 0)
        f = 1;
    else
        f = n*factorial(n-1);
}
`;

const source2 = `
formula isPositive(a: int) = a > 0;
formula small(a: int) = a < 10;

test(a: int)
    requires isPositive(a) and small(a)
    returns b: int
    ensures b > 0 and b < 11
{
    b = a + 1;
}
`;

const source4 = `
rev(a: int[], b: int[], n: int)
    requires n >= 0 and n < length(a) and length(b) == length(a)
    returns void
    ensures forall(k: int | k >= 0 and k < length(a) -> b[k] == a[length(a)-k])
{
    if(n == 0)
        b[0] = a[0];
    else
    {
        b[n] = a[length(a)-n];
        rev(a, b, n-1);
    }
}
`;

run(source1, "requires/ensures");
run(source2, "formulas");
run(source4, "recursion + forall");


// import { parseAndResolve } from "./index";

// const source = `
// rev(a: int[], b: int[], n: int)
//   requires n>=0 and n < length(a) and length(b) == length(a)
//   returns void
//   ensures forall(k: int | (k>=0 and k<length(a)) -> (b[k] == a[length(a)-k]))
// {
//     if(n == 0)
//         b[0] = a[0];
//     else
//     {
//         b[n] = a[length(a) - n];
//         rev(a, b, n - 1);
//     }
// }

// `;

// const ast = parseAndResolve(ex);
// console.log(JSON.stringify(ast, null, 2));
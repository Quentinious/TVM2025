import { parseFunny } from "./src/parser";

async function main() {
    const source = `
        swap(x: int, y: int)
        returns a: int, b: int
        {
            a = y;
            b = x;
        }
    `;

    const mod = await parseFunny("test");
    console.log(mod);
}

main();

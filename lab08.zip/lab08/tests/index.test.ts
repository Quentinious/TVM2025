import { parseFunny } from '../src';
import { testFilesInFolder } from './testFilesInFolder';
export const sampleDir = "/mnt/d/HelloWorld/TVM2025-public/lab08/samples";


describe('08. Testing the sample files', () => {
    testFilesInFolder(sampleDir, parseFunny);
});
